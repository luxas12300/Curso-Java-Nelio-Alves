package Cartao.Models;

public class Cartao {
    private int limite;



    public int getLimite() {
        return limite;
    }

    public void setLimite(int limite) {
        this.limite = limite;
    }
}
